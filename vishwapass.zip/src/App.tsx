/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Globe, 
  School, 
  CheckCircle2, 
  Info, 
  AlertCircle, 
  FileText, 
  Plus, 
  Megaphone, 
  Home as HomeIcon, 
  ClipboardCheck, 
  Vault as VaultIcon, 
  User, 
  Search, 
  Briefcase, 
  Plane, 
  ArrowRight, 
  Lock, 
  Calendar, 
  MapPin, 
  Radio, 
  Clock, 
  Truck, 
  MoreVertical, 
  ShieldAlert, 
  History,
  ChevronRight,
  HelpCircle,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

// --- Components ---

const Header = () => (
  <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-6 h-16 bg-white/70 backdrop-blur-xl border-b border-surface-container">
    <div className="flex items-center gap-2">
      <Globe className="w-6 h-6 text-primary" />
      <span className="text-xl font-extrabold tracking-tighter text-primary font-headline">VishwaPass</span>
    </div>
    <div className="bg-surface-container-low px-3 py-1 rounded-full flex items-center gap-2 cursor-pointer hover:bg-surface-container transition-colors">
      <span className="text-[10px] font-bold tracking-tight text-primary">हिं/EN</span>
    </div>
  </header>
);

const BottomNav = ({ activeTab, onTabChange }: { activeTab: string, onTabChange: (tab: string) => void }) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: HomeIcon },
    { id: 'checklist', label: 'Checklist', icon: ClipboardCheck },
    { id: 'vault', label: 'Vault', icon: VaultIcon },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 pt-3 pb-8 bg-white/70 backdrop-blur-xl border-t border-surface-container rounded-t-3xl shadow-lg">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "flex flex-col items-center justify-center px-4 py-1 transition-all duration-300 rounded-xl",
              isActive ? "bg-primary/10 text-primary scale-110" : "text-outline hover:bg-surface-container-low"
            )}
          >
            <Icon className={cn("w-6 h-6 mb-1", isActive && "fill-primary/20")} />
            <span className="text-[10px] font-semibold tracking-wide">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};

// --- Screens ---

const HomeScreen = ({ onNavigate }: { onNavigate: (screen: string) => void }) => {
  const destinations = [
    {
      name: "United Kingdom",
      price: "₹12,499",
      time: "15-20 Days",
      image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?q=80&w=800&auto=format&fit=crop",
      alt: "London Big Ben"
    },
    {
      name: "United States",
      price: "₹15,800",
      time: "45-60 Days",
      image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?q=80&w=800&auto=format&fit=crop",
      alt: "New York Skyline"
    },
    {
      name: "Germany",
      price: "₹9,900",
      time: "12-15 Days",
      image: "https://images.unsplash.com/photo-1467269204594-9661b134dd2b?q=80&w=800&auto=format&fit=crop",
      alt: "German Town"
    },
    {
      name: "Thailand",
      price: "₹2,500",
      time: "3-5 Days",
      image: "https://images.unsplash.com/photo-1528181304800-2f140819ad9c?q=80&w=800&auto=format&fit=crop",
      alt: "Thailand Beach"
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="pt-24 pb-32 px-6 max-w-2xl mx-auto"
    >
      <section className="mb-12">
        <h1 className="text-4xl font-extrabold text-on-surface mb-4 tracking-tight leading-tight font-headline">
          Where will your <br/>journey take you?
        </h1>
        <p className="text-on-surface-variant mb-8 max-w-md">
          Secure your visa with the precision of a global citizen. Fast, transparent, and prestigious.
        </p>
        <div className="relative group">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-outline" />
          </div>
          <input 
            className="w-full h-16 pl-14 pr-6 rounded-2xl border-none bg-surface-container-low text-on-surface placeholder:text-outline focus:ring-2 focus:ring-primary transition-all shadow-sm"
            placeholder="Search destination country..."
            type="text"
          />
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-xl font-bold tracking-tight mb-6 font-headline">Visa Categories</h2>
        <div className="grid grid-cols-3 gap-4">
          {[
            { icon: School, label: 'Student' },
            { icon: Plane, label: 'Tourist' },
            { icon: Briefcase, label: 'Business' }
          ].map((cat, i) => (
            <button key={i} className="flex flex-col items-center justify-center p-6 bg-white rounded-2xl shadow-sm hover:bg-primary-container group transition-all duration-300">
              <cat.icon className="w-8 h-8 text-primary mb-3 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">{cat.label}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold tracking-tight font-headline">Popular Destinations</h2>
          <button className="text-primary text-sm font-bold flex items-center gap-1">
            View all <ArrowRight className="w-4 h-4" />
          </button>
        </div>
        <div className="grid grid-cols-1 gap-6">
          {destinations.map((dest, i) => (
            <div 
              key={i} 
              onClick={() => onNavigate('checklist')}
              className="group overflow-hidden rounded-2xl bg-surface-container-low transition-all duration-300 cursor-pointer"
            >
              <div className="h-48 relative overflow-hidden">
                <img 
                  src={dest.image} 
                  alt={dest.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-6">
                  <h3 className="text-white text-2xl font-bold font-headline">{dest.name}</h3>
                </div>
              </div>
              <div className="p-6 bg-white">
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-outline mb-1">Starting from</p>
                    <p className="text-lg font-bold text-on-surface">{dest.price}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] uppercase tracking-widest text-outline mb-1">Processing</p>
                    <p className="text-sm font-semibold text-primary">{dest.time}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-12 p-8 bg-primary rounded-3xl relative overflow-hidden">
        <div className="relative z-10">
          <h3 className="text-white text-2xl font-bold mb-2 font-headline">Secure Vault™</h3>
          <p className="text-primary-container text-sm max-w-xs mb-6">
            Your documents are encrypted and stored with sovereign-grade security protocols.
          </p>
          <button 
            onClick={() => onNavigate('vault')}
            className="bg-white text-primary px-6 py-3 rounded-xl font-bold text-sm flex items-center gap-2 active:scale-95 transition-transform"
          >
            <Lock className="w-4 h-4" />
            Open Vault
          </button>
        </div>
        <div className="absolute -right-8 -bottom-8 w-48 h-48 bg-primary-dim rounded-full opacity-50 blur-3xl" />
      </section>
    </motion.div>
  );
};

const ChecklistScreen = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="pt-24 pb-32 px-6 max-w-2xl mx-auto"
    >
      <section className="mb-10">
        <div className="flex items-center gap-2 text-primary font-semibold mb-2">
          <School className="w-4 h-4" />
          <span className="text-[10px] uppercase tracking-widest font-bold">Student Visa Journey</span>
        </div>
        <h1 className="text-4xl font-extrabold text-on-surface tracking-tight mb-4 font-headline">UK Student Visa</h1>
        <div className="bg-surface-container-low rounded-2xl p-6 flex items-center justify-between">
          <div>
            <div className="text-on-surface-variant text-sm mb-1">Overall Progress</div>
            <div className="text-2xl font-bold text-primary">65%</div>
          </div>
          <div className="w-2/3 bg-surface-container h-2 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: '65%' }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="bg-primary h-full" 
            />
          </div>
        </div>
      </section>

      <div className="space-y-4">
        {/* Item 1: Ready */}
        <div className="group bg-white rounded-2xl p-5 shadow-sm transition-all duration-300 hover:bg-surface-container-low">
          <div className="flex items-start justify-between">
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-green-600 fill-green-600/10" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-on-surface">Valid Passport</h3>
                  <Info className="w-4 h-4 text-outline cursor-help" />
                </div>
                <p className="text-sm text-on-surface-variant mt-1">Verified: Expiry Oct 2028</p>
              </div>
            </div>
            <div className="text-[10px] font-bold text-green-600 px-2 py-1 bg-green-100 rounded-full uppercase tracking-tighter">Ready</div>
          </div>
        </div>

        {/* Item 2: Needs Fix */}
        <div className="group bg-white rounded-2xl p-5 shadow-sm transition-all duration-300 hover:bg-surface-container-low border-l-4 border-yellow-400">
          <div className="flex items-start justify-between">
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-yellow-50 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-yellow-600 fill-yellow-600/10" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-on-surface">Bank Statement</h3>
                  <Info className="w-4 h-4 text-outline cursor-help" />
                </div>
                <p className="text-sm text-on-surface-variant mt-1">Uploaded 2 days ago. Statement date is older than 31 days.</p>
                <button className="mt-3 text-xs font-bold text-primary flex items-center gap-1 hover:underline">
                  <Plus className="w-3 h-3" />
                  Re-upload Correct Version
                </button>
              </div>
            </div>
            <div className="text-[10px] font-bold text-yellow-700 px-2 py-1 bg-yellow-100 rounded-full uppercase tracking-tighter">Needs Fix</div>
          </div>
        </div>

        {/* Item 3: Missing */}
        <div className="group bg-white rounded-2xl p-5 shadow-sm transition-all duration-300 hover:bg-surface-container-low">
          <div className="flex items-start justify-between">
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-surface-container flex items-center justify-center">
                <FileText className="w-6 h-6 text-outline" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-outline">CAS Letter</h3>
                  <Info className="w-4 h-4 text-outline cursor-help" />
                </div>
                <p className="text-sm text-outline mt-1">Not yet provided by the University.</p>
                <button className="mt-3 px-4 py-2 bg-surface-container-low text-on-surface text-xs font-bold rounded-xl flex items-center gap-2 hover:bg-surface-container transition-colors">
                  <Plus className="w-3 h-3" />
                  Upload Missing
                </button>
              </div>
            </div>
            <div className="text-[10px] font-bold text-outline px-2 py-1 bg-surface-container rounded-full uppercase tracking-tighter">Missing</div>
          </div>
        </div>

        {/* Item 4: TB Certificate */}
        <div className="group bg-white rounded-2xl p-5 shadow-sm transition-all duration-300 hover:bg-surface-container-low">
          <div className="flex items-start justify-between">
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-green-600 fill-green-600/10" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-on-surface">TB Certificate</h3>
                  <Info className="w-4 h-4 text-outline cursor-help" />
                </div>
                <p className="text-sm text-on-surface-variant mt-1">Verified: Apollo Clinics, Bengaluru</p>
              </div>
            </div>
            <div className="text-[10px] font-bold text-green-600 px-2 py-1 bg-green-100 rounded-full uppercase tracking-tighter">Ready</div>
          </div>
        </div>
      </div>

      <div className="mt-8 p-6 bg-primary/5 rounded-3xl border-2 border-primary/10 relative overflow-hidden group">
        <div className="absolute -right-4 -top-4 opacity-10 scale-150 rotate-12 transition-transform group-hover:rotate-45">
          <Megaphone className="w-24 h-24 text-primary" />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-3">
            <Megaphone className="w-5 h-5 text-primary" />
            <span className="font-bold text-primary font-headline">Visa Expert Tip</span>
          </div>
          <p className="text-sm text-on-surface-variant leading-relaxed">
            Most Indian students are rejected due to "Maintenance Funds" discrepancies. Double check that your bank statement clearly shows the <strong className="text-on-surface">28-day holding period</strong> ending no more than 31 days before application.
          </p>
        </div>
      </div>
    </motion.div>
  );
};

const VaultScreen = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="pt-24 pb-32 px-6 max-w-2xl mx-auto"
    >
      <div className="mb-10">
        <h1 className="text-4xl font-extrabold tracking-tight text-on-surface mb-2 font-headline">Vault</h1>
        <p className="text-on-surface-variant text-sm leading-relaxed max-w-[280px]">
          Your sovereign identity documents, encrypted and accessible globally.
        </p>
      </div>

      <div className="mb-8 p-6 rounded-2xl bg-error-container/10 border-l-4 border-error relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
          <ShieldAlert className="w-24 h-24" />
        </div>
        <div className="flex items-start gap-4">
          <div className="bg-error-container p-2 rounded-xl">
            <AlertCircle className="w-6 h-6 text-on-error-container" />
          </div>
          <div>
            <h3 className="font-headline font-bold text-on-error-container mb-1">Passport Expiry Alert</h3>
            <p className="text-sm text-on-error-container/80 mb-4">
              Your passport expires in 5 months. Most visa applications require 6 months validity.
            </p>
            <button className="bg-error text-white px-5 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 shadow-md shadow-error/20">
              Renew Now
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2 bg-white p-5 rounded-2xl shadow-sm hover:shadow-md transition-all group">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-primary tracking-widest uppercase opacity-60">Primary</p>
                <h4 className="font-headline font-bold text-on-surface">Passport</h4>
              </div>
            </div>
            <MoreVertical className="w-5 h-5 text-on-surface-variant" />
          </div>
          <div className="aspect-[16/9] w-full rounded-xl bg-surface-container overflow-hidden mb-4 border-2 border-transparent group-hover:border-primary/20 transition-all">
            <img 
              className="w-full h-full object-cover opacity-60 grayscale-[0.5] group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500" 
              src="https://images.unsplash.com/photo-1544027993-37dbfe43562a?q=80&w=800&auto=format&fit=crop"
              alt="Passport"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex justify-between items-center text-[10px] font-semibold text-on-surface-variant">
            <span>L-8902XX45</span>
            <span>Updated 2d ago</span>
          </div>
        </div>

        <div className="bg-surface-container-low p-4 rounded-2xl transition-all hover:bg-white hover:shadow-sm group">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
            <User className="w-5 h-5 text-primary" />
          </div>
          <h4 className="font-headline font-bold text-on-surface mb-1">Aadhar Card</h4>
          <p className="text-[10px] text-on-surface-variant mb-4">National Identity</p>
          <div className="aspect-square w-full rounded-xl bg-surface-container mb-4 overflow-hidden">
            <div className="w-full h-full bg-gradient-to-br from-primary/5 to-primary/20 flex items-center justify-center">
              <Lock className="w-8 h-8 text-primary/20" />
            </div>
          </div>
          <span className="text-[9px] font-medium text-on-surface-variant/70">Updated Mar 2024</span>
        </div>

        <div className="bg-surface-container-low p-4 rounded-2xl transition-all hover:bg-white hover:shadow-sm group">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
            <Briefcase className="w-5 h-5 text-primary" />
          </div>
          <h4 className="font-headline font-bold text-on-surface mb-1">PAN Card</h4>
          <p className="text-[10px] text-on-surface-variant mb-4">Financial Doc</p>
          <div className="aspect-square w-full rounded-xl bg-surface-container mb-4 overflow-hidden">
            <div className="w-full h-full bg-gradient-to-br from-primary/5 to-primary/20 flex items-center justify-center">
              <Lock className="w-8 h-8 text-primary/20" />
            </div>
          </div>
          <span className="text-[9px] font-medium text-on-surface-variant/70">Updated Jan 2024</span>
        </div>

        <div className="col-span-2 bg-surface-container-low p-5 rounded-2xl flex items-center justify-between group cursor-pointer hover:bg-white hover:shadow-sm transition-all">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-primary-container flex items-center justify-center overflow-hidden relative">
              <History className="w-7 h-7 text-primary" />
            </div>
            <div>
              <h4 className="font-headline font-bold text-on-surface">Previous Visas</h4>
              <p className="text-xs text-on-surface-variant">Schengen, US-B1/B2, UK Standard</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex -space-x-3">
              {[1, 2, 3].map((_, i) => (
                <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-surface-container flex items-center justify-center text-[8px] font-bold">
                  {i === 2 ? '+3' : ''}
                </div>
              ))}
            </div>
            <ChevronRight className="w-5 h-5 text-on-surface-variant" />
          </div>
        </div>
      </div>

      <button className="fixed bottom-24 right-6 w-14 h-14 rounded-2xl bg-primary text-white flex items-center justify-center shadow-xl z-[60] active:scale-95 transition-transform">
        <Plus className="w-8 h-8" />
      </button>
    </motion.div>
  );
};

const ProfileScreen = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="pt-24 pb-32 px-6 max-w-2xl mx-auto"
    >
      <div className="flex flex-col items-center mb-10">
        <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mb-4 relative">
          <User className="w-12 h-12 text-primary" />
          <div className="absolute bottom-0 right-0 w-8 h-8 bg-primary rounded-full border-4 border-surface flex items-center justify-center">
            <Plus className="w-4 h-4 text-white" />
          </div>
        </div>
        <h2 className="text-2xl font-bold font-headline">Vishal Chaurasiya</h2>
        <p className="text-on-surface-variant text-sm">chaurasiyavishal228@gmail.com</p>
      </div>

      <div className="space-y-4">
        {[
          { icon: ShieldAlert, label: 'Security & Privacy', color: 'text-blue-600' },
          { icon: HelpCircle, label: 'Help & Support', color: 'text-green-600' },
          { icon: BookOpen, label: 'Terms of Service', color: 'text-purple-600' },
          { icon: History, label: 'Journey History', color: 'text-orange-600' },
        ].map((item, i) => (
          <button key={i} className="w-full flex items-center justify-between p-5 bg-white rounded-2xl shadow-sm hover:bg-surface-container-low transition-all">
            <div className="flex items-center gap-4">
              <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center bg-opacity-10", item.color.replace('text', 'bg'))}>
                <item.icon className={cn("w-5 h-5", item.color)} />
              </div>
              <span className="font-semibold">{item.label}</span>
            </div>
            <ChevronRight className="w-5 h-5 text-outline" />
          </button>
        ))}
      </div>

      <button className="w-full mt-10 py-4 text-error font-bold border-2 border-error/10 rounded-2xl hover:bg-error/5 transition-all">
        Sign Out
      </button>
    </motion.div>
  );
};

const TrackingScreen = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="pt-24 pb-32 px-6 max-w-2xl mx-auto"
    >
      <header className="mb-10">
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2 py-0.5 bg-primary-container text-on-primary-container text-[10px] font-bold tracking-widest rounded uppercase">Active Tracking</span>
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight text-on-surface mb-2 font-headline">Schengen Visa Journey</h1>
        <p className="text-on-surface-variant text-sm leading-relaxed max-w-sm">
          Tracking ID: <span className="font-mono font-semibold text-primary">VP-9821-FRA</span>
        </p>
      </header>

      <div className="bg-surface-container-low rounded-3xl p-6 mb-12 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center shadow-sm">
            <Plane className="w-6 h-6 text-primary" />
          </div>
          <div>
            <p className="text-xs text-on-surface-variant font-medium">Destination</p>
            <p className="font-bold text-on-surface">France (Paris)</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-on-surface-variant font-medium">Est. Decision</p>
          <p className="font-bold text-on-surface">Oct 24, 2024</p>
        </div>
      </div>

      <div className="relative pl-4">
        <div className="absolute left-7 top-4 bottom-4 w-0.5 bg-surface-container" />
        
        <div className="relative pl-12 pb-12">
          <div className="absolute left-0 top-1 w-6 h-6 bg-primary rounded-full flex items-center justify-center z-10 border-4 border-surface">
            <CheckCircle2 className="w-3 h-3 text-white" />
          </div>
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-bold text-on-surface">Documents Uploaded</h3>
            <span className="text-[10px] font-bold text-on-surface-variant bg-surface-container px-2 py-0.5 rounded">VishwaPass Status</span>
          </div>
          <p className="text-xs text-on-surface-variant mb-3">All mandatory documents verified by our AI.</p>
          <div className="bg-white p-3 rounded-2xl inline-flex items-center gap-2 shadow-sm">
            <Calendar className="w-4 h-4 text-primary" />
            <span className="text-[11px] font-semibold">Sep 12, 2024</span>
          </div>
        </div>

        <div className="relative pl-12 pb-12">
          <div className="absolute left-0 top-1 w-6 h-6 bg-primary rounded-full flex items-center justify-center z-10 border-4 border-surface">
            <CheckCircle2 className="w-3 h-3 text-white" />
          </div>
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-bold text-on-surface">VFS Appointment</h3>
            <span className="text-[10px] font-bold text-on-surface-variant bg-surface-container px-2 py-0.5 rounded">Embassy Status</span>
          </div>
          <p className="text-xs text-on-surface-variant mb-3">Biometrics and physical file submitted at VFS Global.</p>
          <div className="bg-white p-3 rounded-2xl inline-flex items-center gap-2 shadow-sm">
            <MapPin className="w-4 h-4 text-primary" />
            <span className="text-[11px] font-semibold">Sep 28, 2024 (VFS New Delhi)</span>
          </div>
        </div>

        <div className="relative pl-12 pb-12">
          <div className="absolute left-0 top-1 w-6 h-6 bg-primary rounded-full flex items-center justify-center z-10 border-4 border-primary-container outline outline-4 outline-primary/10">
            <div className="w-2 h-2 bg-white rounded-full" />
          </div>
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-bold text-primary">Embassy Submission</h3>
            <span className="text-[10px] font-bold text-primary bg-primary-container px-2 py-0.5 rounded">Embassy Status</span>
          </div>
          <p className="text-xs text-on-surface leading-relaxed mb-3">Application successfully received by the Embassy of France.</p>
          <div className="bg-primary text-white p-4 rounded-2xl shadow-lg shadow-primary/10 mb-2">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold tracking-widest uppercase opacity-80">Live Update</span>
              <Radio className="w-4 h-4 animate-pulse" />
            </div>
            <p className="text-sm font-semibold">Your passport is being processed.</p>
          </div>
          <span className="text-[10px] font-medium text-on-surface-variant italic">Last updated: 2 hours ago</span>
        </div>

        <div className="relative pl-12 pb-12 opacity-40">
          <div className="absolute left-0 top-1 w-6 h-6 bg-surface-container rounded-full flex items-center justify-center z-10 border-4 border-surface" />
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-bold text-on-surface">Under Review</h3>
            <span className="text-[10px] font-bold text-on-surface-variant bg-surface-container px-2 py-0.5 rounded">Embassy Status</span>
          </div>
          <p className="text-xs text-on-surface-variant mb-3">Final verification of financial and travel documents.</p>
          <div className="flex items-center gap-2 text-[11px] font-semibold text-on-surface-variant">
            <Clock className="w-4 h-4" />
            <span>Expected Oct 15</span>
          </div>
        </div>

        <div className="relative pl-12 opacity-40">
          <div className="absolute left-0 top-1 w-6 h-6 bg-surface-container rounded-full flex items-center justify-center z-10 border-4 border-surface" />
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-bold text-on-surface">Decision Ready</h3>
            <span className="text-[10px] font-bold text-on-surface-variant bg-surface-container px-2 py-0.5 rounded">VishwaPass Status</span>
          </div>
          <p className="text-xs text-on-surface-variant mb-3">Passport ready for collection or courier dispatch.</p>
          <div className="flex items-center gap-2 text-[11px] font-semibold text-on-surface-variant">
            <Truck className="w-4 h-4" />
            <span>Estimated Oct 24</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':
        return <HomeScreen onNavigate={setActiveTab} />;
      case 'checklist':
        return <ChecklistScreen />;
      case 'vault':
        return <VaultScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'tracking':
        return <TrackingScreen />;
      default:
        return <HomeScreen onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-surface selection:bg-primary/10 selection:text-primary">
      <Header />
      
      <main className="relative">
        <AnimatePresence mode="wait">
          {renderScreen()}
        </AnimatePresence>
      </main>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}
